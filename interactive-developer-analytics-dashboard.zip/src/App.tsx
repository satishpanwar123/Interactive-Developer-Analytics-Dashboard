import {
  useState,
  useMemo,
  useEffect,
  type ReactNode,
} from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import {
  Activity,
  GitPullRequest,
  Code,
  ShieldAlert,
  TrendingUp,
  TrendingDown,
  Sun,
  Moon,
  Filter,
  Calendar,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  MoreHorizontal,
  RefreshCcw,
  Users,
  GitBranch,
} from "lucide-react";
import { format, subDays } from "date-fns";

// -------------------------------------------------------------------
// Types
// -------------------------------------------------------------------
interface CommitData {
  date: string;
  commits: number;
  prs: number;
  reviews: number;
}

interface RepoData {
  name: string;
  commits: number;
  prs: number;
  issues: number;
  health: number;
}

interface ActivityRow {
  id: string;
  type: "commit" | "pr" | "issue" | "review";
  title: string;
  author: string;
  repo: string;
  time: string;
  status: "open" | "merged" | "closed" | "pending";
  branch: string;
}

interface KPIStat {
  label: string;
  value: number | string;
  change: number;
  trend: "up" | "down" | "neutral";
  icon: ReactNode;
  suffix?: string;
}

// -------------------------------------------------------------------
// Sample Data Generation
// -------------------------------------------------------------------
const generateCommitData = (days: number): CommitData[] => {
  const data: CommitData[] = [];
  const baseCommits = 45;
  const basePRs = 8;
  const baseReviews = 12;
  for (let i = days - 1; i >= 0; i--) {
    const date = subDays(new Date(), i);
    const variance = 1 + Math.sin(i / 3) * 0.3 + Math.random() * 0.4;
    data.push({
      date: format(date, "MMM d"),
      commits: Math.round(baseCommits * variance),
      prs: Math.round(basePRs * variance),
      reviews: Math.round(baseReviews * variance),
    });
  }
  return data;
};

const generateRepoData = (): RepoData[] => [
  { name: "core-platform", commits: 1240, prs: 89, issues: 23, health: 92 },
  { name: "frontend-sdk", commits: 980, prs: 67, issues: 18, health: 88 },
  { name: "auth-service", commits: 760, prs: 45, issues: 12, health: 95 },
  { name: "payment-gateway", commits: 640, prs: 38, issues: 31, health: 74 },
  { name: "notification-svc", commits: 420, prs: 29, issues: 8, health: 81 },
  { name: "analytics-engine", commits: 310, prs: 22, issues: 15, health: 79 },
];

const generateActivityData = (): ActivityRow[] => {
  const types: ActivityRow["type"][] = ["commit", "pr", "issue", "review"];
  const statuses: ActivityRow["status"][] = ["open", "merged", "closed", "pending"];
  const authors = ["Sarah Chen", "Marcus Liu", "Elena Rodriguez", "David Kim", "Aisha Patel"];
  const repos = ["core-platform", "frontend-sdk", "auth-service", "payment-gateway", "notification-svc"];
  const titles = [
    "Fix memory leak in connection pool",
    "Add OAuth2 provider support",
    "Refactor authentication middleware",
    "Update dependency versions",
    "Implement rate limiting",
    "Add dark mode to dashboard",
    "Optimize database queries",
    "Fix CORS configuration",
    "Add API versioning",
    "Improve error handling",
  ];
  const branches = ["main", "develop", "feature/auth", "hotfix/login", "release/v2.1"];

  const data: ActivityRow[] = [];
  for (let i = 0; i < 20; i++) {
    const type = types[Math.floor(Math.random() * types.length)];
    const status = statuses[Math.floor(Math.random() * statuses.length)];
    const hoursAgo = Math.floor(Math.random() * 72) + 1;
    const time = hoursAgo < 24 ? `${hoursAgo}h ago` : `${Math.floor(hoursAgo / 24)}d ago`;
    data.push({
      id: `ACT-${1000 + i}`,
      type,
      title: titles[Math.floor(Math.random() * titles.length)],
      author: authors[Math.floor(Math.random() * authors.length)],
      repo: repos[Math.floor(Math.random() * repos.length)],
      time,
      status,
      branch: branches[Math.floor(Math.random() * branches.length)],
    });
  }
  return data;
};

// -------------------------------------------------------------------
// Colors
// -------------------------------------------------------------------
const COLORS = {
  success: "#10b981",
  warning: "#f59e0b",
  danger: "#ef4444",
};

// -------------------------------------------------------------------
// Components
// -------------------------------------------------------------------

const KPICard = ({ stat }: { stat: KPIStat }) => {
  const trendIcon =
    stat.trend === "up" ? <TrendingUp className="w-4 h-4" /> : stat.trend === "down" ? <TrendingDown className="w-4 h-4" /> : (
      <svg xmlns="http://www.w3.org/2000/svg" width={24} height={24} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4"><line x1="5" y1="12" x2="19" y2="12" /></svg>
    );
  const trendColor =
    stat.trend === "up"
      ? "text-green-500 bg-green-50"
      : stat.trend === "down"
        ? "text-red-500 bg-red-50"
        : "text-gray-500 bg-gray-50";

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-200 dark:border-gray-700 shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <div className="p-3 rounded-lg bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400">{stat.icon}</div>
        <div className={`flex items-center gap-1.5 text-xs font-medium ${trendColor}`}>
          {trendIcon}
          <span>{Math.abs(stat.change)}%</span>
        </div>
      </div>
      <div className="flex items-baseline gap-2">
        <span className="text-3xl font-bold text-gray-900 dark:text-white">{stat.value}{stat.suffix ?? ""}</span>
      </div>
      <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">{stat.label}</p>
    </div>
  );
};

const LineChartCommits = ({ data }: { data: CommitData[] }) => (
  <div className="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-200 dark:border-gray-700 shadow-sm">
    <div className="flex items-center justify-between mb-6">
      <h3 className="font-semibold text-gray-900 dark:text-white">Commits Over Time</h3>
      <div className="h-8 w-8 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center">
        <RefreshCcw className="w-4 h-4 text-gray-500" />
      </div>
    </div>
    <div className="h-80 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 20, right: 30, bottom: 20, left: 10 }}>
          <defs>
            <linearGradient id="colorCommits" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#3b82f6" stopOpacity={0.8} />
              <stop offset="100%" stopColor="#3b82f6" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" vertical={false} />
          <XAxis dataKey="date" tick={{ fontSize: 12, fill: "#6b7280" }} axisLine={false} tickLine={false} />
          <YAxis tick={{ fontSize: 12, fill: "#6b7280" }} axisLine={false} tickLine={false} />
          <Tooltip contentStyle={{ backgroundColor: "#1f2937", border: "none", borderRadius: "8px", padding: "8px 12px" }} />
          <Legend />
          <Line type="monotone" dataKey="commits" stroke="#3b82f6" strokeWidth={3} dot={false} activeDot={{ r: 6 }} fill="#3b82f6" />
          <Line type="monotone" dataKey="prs" stroke="#8b5cf6" strokeWidth={3} dot={false} activeDot={{ r: 6 }} fill="#8b5cf6" />
          <Line type="monotone" dataKey="reviews" stroke="#10b981" strokeWidth={3} dot={false} activeDot={{ r: 6 }} fill="#10b981" />
        </LineChart>
      </ResponsiveContainer>
    </div>
    <div className="mt-4 flex gap-6 text-xs">
      <div className="flex items-center gap-2">
        <span className="w-3 h-3 rounded-full bg-blue-500" />
        <span className="text-gray-500 dark:text-gray-400">Commits</span>
      </div>
      <div className="flex items-center gap-2">
        <span className="w-3 h-3 rounded-full bg-purple-500" />
        <span className="text-gray-500 dark:text-gray-400">Pull Requests</span>
      </div>
      <div className="flex items-center gap-2">
        <span className="w-3 h-3 rounded-full bg-green-500" />
        <span className="text-gray-500 dark:text-gray-400">Code Reviews</span>
      </div>
    </div>
  </div>
);

const BarChartRepos = ({ data }: { data: RepoData[] }) => (
  <div className="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-200 dark:border-gray-700 shadow-sm">
    <div className="flex items-center justify-between mb-6">
      <h3 className="font-semibold text-gray-900 dark:text-white">Activity by Repository</h3>
      <span className="text-xs text-gray-500 dark:text-gray-400">Last 14 days</span>
    </div>
    <div className="h-80 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 20, right: 30, bottom: 50, left: 20 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" horizontal={false} />
          <XAxis dataKey="name" tick={{ fontSize: 12, fill: "#6b7280" }} axisLine={false} tickLine={false} angle={-45} textAnchor="end" />
          <YAxis tick={{ fontSize: 12, fill: "#6b7280" }} axisLine={false} tickLine={false} />
          <Tooltip contentStyle={{ backgroundColor: "#1f2937", border: "none", borderRadius: "8px", padding: "8px 12px" }} />
          <Bar dataKey="commits" fill="#3b82f6" radius={[4, 4, 0, 0]} />
          <Bar dataKey="prs" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
          <Bar dataKey="issues" fill="#ef4444" radius={[4, 4, 0, 0]} />
          <Legend verticalAlign="bottom" align="center" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  </div>
);

const DonutChartHealth = ({ data }: { data: RepoData[] }) => (
  <div className="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-200 dark:border-gray-700 shadow-sm">
    <div className="flex items-center justify-between mb-6">
      <h3 className="font-semibold text-gray-900 dark:text-white">Repository Health</h3>
      <span className="text-xs text-gray-500 dark:text-gray-400">Score out of 100</span>
    </div>
    <div className="flex flex-col lg:flex-row gap-8 items-center">
      <div className="w-full lg:w-80">
        <ResponsiveContainer width="100%" height={280}>
          <PieChart>
            <Pie
              data={data.map((d) => ({ name: d.name, value: d.health }))}
              cx="50%"
              cy="50%"
              innerRadius={80}
              outerRadius={100}
              dataKey="value"
              labelLine={false}
              label={{ fill: "#6b7280", fontSize: 12, position: "outside" }}
            >
              {data.map((_, index) => (
                <Cell key={`cell-${index}`} fill="#3b82f6" />
              ))}
            </Pie>
          </PieChart>
        </ResponsiveContainer>
      </div>
      <div className="w-full lg:w-auto space-y-4">
        {data.map((repo) => {
          const color = repo.health >= 85 ? COLORS.success : repo.health >= 75 ? COLORS.warning : COLORS.danger;
          return (
            <div key={repo.name} className="flex items-center gap-3">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: color }} />
              <div className="flex-1">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-900 dark:text-white">{repo.name}</span>
                  <span className="font-medium text-gray-900 dark:text-white">{repo.health}</span>
                </div>
                <div className="w-full h-1.5 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                  <div className="h-full" style={{ width: `${repo.health}%`, backgroundColor: color }} />
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  </div>
);

const BarChartIssues = ({ data }: { data: RepoData[] }) => (
  <div className="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-200 dark:border-gray-700 shadow-sm">
    <div className="flex items-center justify-between mb-6">
      <h3 className="font-semibold text-gray-900 dark:text-white">Open Issues by Repo</h3>
      <span className="text-xs text-gray-500 dark:text-gray-400">Current backlog</span>
    </div>
    <div className="h-64 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} layout="vertical" margin={{ top: 20, right: 100, bottom: 20, left: 10 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" vertical={false} />
          <YAxis dataKey="name" tick={{ fontSize: 12, fill: "#6b7280" }} axisLine={false} tickLine={false} width={110} />
          <XAxis tick={{ fontSize: 12, fill: "#6b7280" }} axisLine={false} tickLine={false} />
          <Tooltip contentStyle={{ backgroundColor: "#1f2937", border: "none", borderRadius: "8px", padding: "8px 12px" }} />
          <Bar dataKey="issues" fill="#ef4444" radius={[0, 4, 4, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  </div>
);

const DataTable = ({ data, searchTerm, setSearchTerm, statusFilter }: { data: ActivityRow[]; searchTerm: string; setSearchTerm: (v: string) => void; statusFilter: string }) => {
  const filteredData = useMemo(() => {
    return data.filter((row) => {
      const matchesSearch =
        row.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        row.author.toLowerCase().includes(searchTerm.toLowerCase()) ||
        row.repo.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesStatus = statusFilter === "all" || row.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [data, searchTerm, statusFilter]);

  const typeIcons: Record<string, ReactNode> = {
    commit: <GitBranch className="w-4 h-4 text-gray-500" />,
    pr: <GitPullRequest className="w-4 h-4 text-blue-500" />,
    issue: <ShieldAlert className="w-4 h-4 text-red-500" />,
    review: <Activity className="w-4 h-4 text-purple-500" />,
  };

  const statusColors: Record<string, string> = {
    open: "bg-blue-100 text-blue-700 dark:bg-blue-900/20 dark:text-blue-400",
    merged: "bg-green-100 text-green-700 dark:bg-green-900/20 dark:text-green-400",
    closed: "bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-300",
    pending: "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/20 dark:text-yellow-400",
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-200 dark:border-gray-700 shadow-sm">
      <div className="flex items-center justify-between mb-6">
        <h3 className="font-semibold text-gray-900 dark:text-white">Recent Activity</h3>
        <div className="relative">
          <svg xmlns="http://www.w3.org/2000/svg" width={24} height={24} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2"><circle cx="11" cy="11" r="8" /><path d="M21 21l-4.35-4.35" /></svg>
          <input
            type="text"
            placeholder="Search activity…"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 pr-4 py-2 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 w-64"
          />
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left">
          <thead>
            <tr className="border-b border-gray-200 dark:border-gray-600">
              <th className="pb-3 font-medium text-gray-500 dark:text-gray-300">ID</th>
              <th className="pb-3 font-medium text-gray-500 dark:text-gray-300">Type</th>
              <th className="pb-3 font-medium text-gray-500 dark:text-gray-300">Title</th>
              <th className="pb-3 font-medium text-gray-500 dark:text-gray-300">Author</th>
              <th className="pb-3 font-medium text-gray-500 dark:text-gray-300">Repo</th>
              <th className="pb-3 font-medium text-gray-500 dark:text-gray-300">Branch</th>
              <th className="pb-3 font-medium text-gray-500 dark:text-gray-300">Time</th>
              <th className="pb-3 font-medium text-gray-500 dark:text-gray-300">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
            {filteredData.map((row) => (
              <tr key={row.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                <td className="py-3 text-gray-900 dark:text-white font-mono text-xs">{row.id}</td>
                <td className="py-3 flex items-center gap-2">{typeIcons[row.type]}</td>
                <td className="py-3 text-gray-900 dark:text-white">{row.title}</td>
                <td className="py-3 text-gray-900 dark:text-white">{row.author}</td>
                <td className="py-3 text-gray-900 dark:text-white">{row.repo}</td>
                <td className="py-3 text-gray-500 dark:text-gray-400 text-xs font-mono">{row.branch}</td>
                <td className="py-3 text-gray-500 dark:text-gray-400 text-xs">{row.time}</td>
                <td className="py-3">
                  <span className={`px-2 py-1 rounded text-xs font-medium ${statusColors[row.status]}`}>{row.status}</span>
                </td>
              </tr>
            ))}
            {filteredData.length === 0 && (
              <tr>
                <td colSpan={8} className="py-8 text-center text-gray-500 dark:text-gray-400">
                  No activity found matching your filters.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      <div className="mt-4 flex items-center justify-between text-xs text-gray-500 dark:text-gray-400">
        <span>Showing {filteredData.length} of {data.length} activities</span>
        <div className="flex gap-2">
          <button className="px-3 py-1 rounded hover:bg-gray-100 dark:hover:bg-gray-700"><ChevronLeft className="w-3 h-3" /></button>
          <button className="px-3 py-1 rounded hover:bg-gray-100 dark:hover:bg-gray-700"><ChevronRight className="w-3 h-3" /></button>
        </div>
      </div>
    </div>
  );
};

// -------------------------------------------------------------------
// Main App
// -------------------------------------------------------------------
export default function App() {
  const [darkMode, setDarkMode] = useState(false);
  const [dateRange, setDateRange] = useState<{ label: string; days: number }>({ label: "Last 14 Days", days: 14 });
  const [segmentFilter, setSegmentFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [showDateDropdown, setShowDateDropdown] = useState(false);
  const [showSegmentDropdown, setShowSegmentDropdown] = useState(false);
  const [showStatusDropdown, setShowStatusDropdown] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem("dashboard-theme");
    if (saved !== null) setDarkMode(saved === "true");
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", darkMode);
    localStorage.setItem("dashboard-theme", String(darkMode));
  }, [darkMode]);

  const commitData = useMemo(() => generateCommitData(dateRange.days), [dateRange.days]);
  const repoData = useMemo(() => generateRepoData(), []);
  const activityData = useMemo(() => generateActivityData(), []);

  const totalCommits = commitData.reduce((sum, d) => sum + d.commits, 0);
  const totalPRs = commitData.reduce((sum, d) => sum + d.prs, 0);
  const totalReviews = commitData.reduce((sum, d) => sum + d.reviews, 0);
  const avgHealth = Math.round(repoData.reduce((sum, d) => sum + d.health, 0) / repoData.length);

  const kpis: KPIStat[] = [
    { label: "Total Commits", value: totalCommits, change: 12, trend: "up", icon: <Code className="w-5 h-5" /> },
    { label: "Pull Requests", value: totalPRs, change: 5, trend: "down", icon: <GitPullRequest className="w-5 h-5" /> },
    { label: "Code Reviews", value: totalReviews, change: 18, trend: "up", icon: <Activity className="w-5 h-5" /> },
    { label: "Repo Health", value: avgHealth, change: 3, trend: "up", icon: <ShieldAlert className="w-5 h-5" />, suffix: "/100" },
  ];

  const dateRangeOptions = [
    { label: "Last 7 Days", days: 7 },
    { label: "Last 14 Days", days: 14 },
    { label: "Last 30 Days", days: 30 },
    { label: "Last 90 Days", days: 90 },
  ];

  const segmentOptions = [
    { label: "All Teams", value: "all" },
    { label: "Frontend", value: "frontend" },
    { label: "Backend", value: "backend" },
    { label: "DevOps", value: "devops" },
  ];

  const statusOptions = [
    { label: "All Statuses", value: "all" },
    { label: "Open", value: "open" },
    { label: "Merged", value: "merged" },
    { label: "Closed", value: "closed" },
    { label: "Pending", value: "pending" },
  ];

  const handleReset = () => {
    setDateRange({ label: "Last 14 Days", days: 14 });
    setSegmentFilter("all");
    setStatusFilter("all");
    setShowDateDropdown(false);
    setShowSegmentDropdown(false);
    setShowStatusDropdown(false);
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100 transition-colors duration-300">
      <header className="sticky top-0 z-40 bg-white/80 dark:bg-gray-900/80 backdrop-blur-md border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold">CD</div>
            <span className="font-bold text-xl tracking-tight">CodeCollab <span className="text-blue-500">Analytics</span></span>
          </div>
          <div className="flex items-center gap-4">
            <div
              onClick={() => setShowDateDropdown(!showDateDropdown)}
              className="flex items-center gap-2 px-4 py-2 bg-gray-50 dark:bg-gray-800 rounded-full border border-gray-200 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors cursor-pointer"
            >
              <Calendar className="w-4 h-4 text-gray-500" />
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{dateRange.label}</span>
              <ChevronDown className={`w-3 h-3 text-gray-400 transition-transform duration-200 ${showDateDropdown ? "rotate-180" : ""}`} />
            </div>
            <button onClick={() => setDarkMode(!darkMode)} className="p-2 rounded-lg text-gray-500 hover:text-gray-900 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors" aria-label="Toggle dark mode">
              {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>
            <button className="p-2 rounded-full text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors">
              <MoreHorizontal className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-8 space-y-8">
        {/* Filter Bar */}
        <div className="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-200 dark:border-gray-700 shadow-sm">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="relative group">
              <div onClick={() => setShowDateDropdown(!showDateDropdown)} className="flex items-center gap-3 cursor-pointer">
                <Filter className="w-5 h-5 text-gray-400 group-hover:text-blue-500 transition-colors" />
                <div>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Date Range</p>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium text-gray-900 dark:text-white">{dateRange.label}</span>
                    <ChevronDown className={`w-3 h-3 text-gray-400 transition-transform duration-200 ${showDateDropdown ? "rotate-180" : ""}`} />
                  </div>
                </div>
              </div>
              {showDateDropdown && (
                <div className="absolute bottom-full left-0 w-full mb-2 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600 rounded-lg shadow-lg py-2 z-50">
                  {dateRangeOptions.map((opt) => (
                    <button
                      key={opt.label}
                      onClick={() => { setDateRange(opt); setShowDateDropdown(false); }}
                      className="w-full text-left px-4 py-2 text-sm hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-colors"
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div className="relative group">
              <div onClick={() => setShowSegmentDropdown(!showSegmentDropdown)} className="flex items-center gap-3 cursor-pointer">
                <Users className="w-5 h-5 text-gray-400 group-hover:text-blue-500 transition-colors" />
                <div>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Segment</p>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium text-gray-900 dark:text-white">{segmentOptions.find((s) => s.value === segmentFilter)?.label}</span>
                    <ChevronDown className={`w-3 h-3 text-gray-400 transition-transform duration-200 ${showSegmentDropdown ? "rotate-180" : ""}`} />
                  </div>
                </div>
              </div>
              {showSegmentDropdown && (
                <div className="absolute bottom-full left-0 w-full mb-2 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600 rounded-lg shadow-lg py-2 z-50">
                  {segmentOptions.map((opt) => (
                    <button
                      key={opt.label}
                      onClick={() => { setSegmentFilter(opt.value); setShowSegmentDropdown(false); }}
                      className="w-full text-left px-4 py-2 text-sm hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-colors"
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div className="relative group">
              <div onClick={() => setShowStatusDropdown(!showStatusDropdown)} className="flex items-center gap-3 cursor-pointer">
                <ShieldAlert className="w-5 h-5 text-gray-400 group-hover:text-blue-500 transition-colors" />
                <div>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Status</p>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium text-gray-900 dark:text-white">{statusOptions.find((s) => s.value === statusFilter)?.label}</span>
                    <ChevronDown className={`w-3 h-3 text-gray-400 transition-transform duration-200 ${showStatusDropdown ? "rotate-180" : ""}`} />
                  </div>
                </div>
              </div>
              {showStatusDropdown && (
                <div className="absolute bottom-full left-0 w-full mb-2 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600 rounded-lg shadow-lg py-2 z-50">
                  {statusOptions.map((opt) => (
                    <button
                      key={opt.label}
                      onClick={() => { setStatusFilter(opt.value); setShowStatusDropdown(false); }}
                      className="w-full text-left px-4 py-2 text-sm hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-colors"
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div className="flex items-center justify-end">
              <button onClick={handleReset} className="px-4 py-2 text-sm font-medium text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/20 rounded-lg hover:bg-blue-100 dark:hover:bg-blue-900/30 transition-colors flex items-center gap-2">
                <RefreshCcw className="w-4 h-4" /> Reset
              </button>
            </div>
          </div>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {kpis.map((kpi, i) => <KPICard key={i} stat={kpi} />)}
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <LineChartCommits data={commitData} />
          <BarChartRepos data={repoData} />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <DonutChartHealth data={repoData} />
          <BarChartIssues data={repoData} />
        </div>

        {/* Data Table */}
        <DataTable data={activityData} searchTerm={searchTerm} setSearchTerm={setSearchTerm} statusFilter={statusFilter} />
      </div>
    </div>
  );
}
